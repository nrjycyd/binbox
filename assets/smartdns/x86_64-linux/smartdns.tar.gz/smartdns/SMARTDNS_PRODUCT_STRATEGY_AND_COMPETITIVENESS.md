# SmartDNS 产品竞争力、管理体验与生态规划

## 1. 结论与定位

SmartDNS 不应定位为“又一个广告过滤 DNS”，而应定位为：

> 面向家庭网络、路由器和高级用户的智能 DNS、设备访问控制与网络问题诊断平台。

Pi-hole 的核心心智是“家庭广告过滤”，AdGuard Home 的核心心智是“隐私过滤与开箱即用”，而 SmartDNS 应占据另一条主线：

```text
为每台设备选择更合适的解析和访问路径，
控制它能访问什么，并解释它为什么打不开或变慢。
```

SmartDNS 在多上游并发、最快 IP、双栈处理、复杂 DNS 路由、透明数据转发和诊断可解释性上有明显技术优势。产品工作重点不再是继续增加 DNS 协议，而是把现有能力组织成普通家庭也能理解、验证和修复的问题闭环。

## 2. 当前能力盘点

下表以当前 SmartDNS 核心、WebUI 与管理插件能力为准。

| 能力域 | 已有能力 | 用户价值 |
| --- | --- | --- |
| 智能解析 | 多上游并发、最快 IP 选择、缓存、测速、域名/IP 路由 | 减少单上游故障和不合适 IP 带来的访问慢或失败 |
| 现代 DNS | UDP、TCP、DoT、DoH、DoQ、DoH3、DNS64、IPv4/IPv6 双栈 | 在隐私、兼容性和双栈网络中保持选择空间 |
| 设备识别 | MAC、IP、CIDR、客户端名称、MAC 厂商和 IPv4/IPv6 聚合 | 不依赖 SmartDNS 承担 DHCP 也能管理设备 |
| 网络策略中心 | 解析组、继承、上游、规则、监听器、订阅、客户端的聚合工作台 | 用“策略”而不是零散配置项组织复杂 DNS 能力 |
| 应用控制 | 应用目录、应用域名集合、应用活动、按设备阻断/放行、定时规则、临时放行 | 用户可以表达“限制短视频”，而不是维护域名列表 |
| 访问诊断 | 指定设备短时捕获 DNS 与转发事件；从捕获结果保存应用或创建规则 | 回答“手机为什么打不开/为什么慢” |
| 实时可视化 | DNS 与实际数据转发的流量拓扑、客户端实时活动、查询日志 | 同时看见解析路径和真实连接路径 |
| 数据转发 | TPROXY、SOCKS5、HTTP(S)、SNI 等转发服务及连接/流量统计 | 覆盖旁路由、复杂代理与透明转发场景 |
| 运维管理 | 状态、缓存、上游、证书、日志、审计、配置资源 API | 适合长期运行和 WebUI 自动化管理 |

SmartDNS 官方功能说明可参见：[SmartDNS Documentation](https://pymumu.github.io/smartdns/en/)。

## 3. 当前 WebUI 的产品结构

当前导航应维持“看概览、做控制、做观察、配底层、做维护”的层次：

```text
Dashboard / Traffic Topology
  └ 看整体状态和真实访问路径

Access Control
  ├ Device Policies
  ├ App Catalog
  └ Subscriptions

Network Policy Center
  └ 解析组工作台：设备 -> 组 -> DNS 上游、规则、监听器、可选转发

Clients / Query Log / Access Diagnostics
  └ 看某台设备做了什么，以及一次问题为什么发生

DNS Configuration / Network Services
  └ 专家级 DNS、规则、监听器、代理和数据转发配置

System
  └ 状态、证书、日志、系统维护
```

### 3.1 网络策略中心

“网络策略中心”只是现有解析组的用户工作台，不应创建第二套 `policy-group` 配置实体。

```text
设备 / MAC / IP
  -> client-rules / Device Policy
    -> 解析组
      -> 多 DNS 上游、域名/IP 规则、订阅、组级设置
      -> 可选 proxy-bind / TPROXY / SNI / 数据转发
```

原“解析组”不应和“策略组”同时作为两个用户概念出现。底层保持解析组，页面对用户呈现为网络策略中心；监听器、上游和原始规则仍在专家配置页中维护。

### 3.2 Access Control 与应用目录

Access Control 是普通用户最重要的入口，应让用户看到：

```text
哪些设备受保护
哪些应用正在被阻断
当前有哪些临时放行
设备今天主要使用了什么应用
```

应用目录是 SmartDNS 的重要差异化资产。它将域名集合映射为应用、厂商和分类；访问诊断可将用户实际复现时看到的域名沉淀为应用目录。

需要明确其边界：DNS 域名不等于绝对准确的“应用身份”。共享 CDN、系统后台请求、加密 DNS、VPN、ECH 和动态域名都可能降低归因置信度。共享基础设施默认不应被一键阻断。

### 3.3 客户端统计与访问诊断的分工

两者不应重复建设。

| 页面 | 回答的问题 |
| --- | --- |
| 客户端统计 | 这台设备平时访问什么、哪些应用被阻断、查询和失败趋势如何？ |
| 访问诊断 | 用户刚复现的一次问题，DNS、双栈、规则、上游和转发连接发生了什么？ |

客户端统计应提供“最近一次诊断”摘要和跳转；访问诊断在会话结束时应提供可读结论、证据和修复入口，而不是另建一套长期统计页。

## 4. 与 Pi-hole、AdGuard Home 的比较

### 4.1 定性评分

| 维度 | SmartDNS | Pi-hole | AdGuard Home | 结论 |
| --- | --- | --- | --- | --- |
| 多上游、最快 IP、双栈优化 | 强 | 中 | 中 | SmartDNS 优势 |
| 加密 DNS 与协议广度 | 强 | 中 | 强 | SmartDNS 与 AdGuard Home 均强 |
| 设备策略与解析组 | 强 | 强 | 强 | SmartDNS 的“策略 + 路径”表达更完整 |
| 应用级访问控制 | 有潜力 | 弱 | 强 | 目录质量决定 SmartDNS 是否领先 |
| 广告/追踪/恶意内容过滤 | 中 | 强 | 很强 | AdGuard Home 领先 |
| 流量拓扑与访问诊断 | 很强 | 弱 | 弱 | SmartDNS 明显差异化 |
| TPROXY/SOCKS/真实数据转发 | 很强 | 弱 | 弱 | SmartDNS 明显差异化 |
| 首次部署与普通用户体验 | 中 | 强 | 很强 | 仍需补强 |
| 社区、教程与第三方生态 | 中 | 很强 | 很强 | 仍需补强 |
| 运维生态与可观测性 | 中 | 强 | 强 | Prometheus/HA 后可改善 |

### 4.2 Pi-hole 做得更好的地方

Pi-hole 的优势主要在成熟、简单和社区心智：

- 用户很容易理解其“查询日志、允许、阻断、过滤列表、分组”模型；
- 长期积累了大量教程、Docker/NAS/路由器部署经验；
- 分组、过滤列表和 API 稳定，第三方工具丰富；
- 更适合只希望获得家庭广告过滤的用户。

参考：[Pi-hole Group Management](https://docs.pi-hole.net/group_management/)、[Pi-hole API](https://docs.pi-hole.net/api/)。

### 4.3 AdGuard Home 做得更好的地方

AdGuard Home 的主要优势是过滤内容产品化：

- 成熟的 Adblock/AdGuard 规则生态与例外语义；
- SafeSearch、成人内容保护、安全浏览和服务级阻断；
- CNAME Cloaking 等广告规避处理；
- 默认列表、分类和开箱配置对普通用户更友好；
- 客户端标签、过滤策略与 DHCP 集成较完善。

参考：[AdGuard Home Configuration](https://adguard-dns.io/kb/de/adguard-home/configuration/)、[AdGuard Home Clients](https://adguard-dns.io/kb/adguard-home/clients/)、[CNAME Cloaking FAQ](https://adguard-dns.io/kb/es/adguard-home/faq/)。

SmartDNS 的 MAC 策略管理不要求自身承担 DHCP，这对保留既有路由器 DHCP 的用户是优势；而 AdGuard Home 的 MAC 客户端识别通常依赖其 DHCP 模式。

## 5. SmartDNS 应形成的差异化闭环

最有竞争力的不是孤立功能，而是如下闭环：

```text
设备访问了什么应用
  -> 是否命中预期策略
    -> DNS / 双栈 / 上游 / 转发在哪一层失败或变慢
      -> 给出可确认的修复建议
        -> 应用策略或规则
          -> 验证问题是否消失
```

建议的外部表达：

> 让每台设备获得更合适的网络访问路径；当访问异常时，给出有证据的解释和修复办法。

数据转发是高级差异化能力，不应成为纯 DNS 或家长控制用户的必经配置。

## 6. 下一阶段优先级

### P0：形成可靠、可解释的策略产品

#### 6.1 官方签名应用目录

- 支持官方订阅、签名验证、版本、更新日志、来源和失效提示；
- 应用记录包含分类、厂商、地区版本、置信度和共享 CDN 风险；
- 用户覆盖不被订阅更新覆盖；
- 支持从访问诊断提交“缺失域名/错误归类”的反馈包；
- 对共享域名默认只建议，不自动加入阻断规则。

这是应用控制能否超过“手工域名列表”的关键。

#### 6.2 轻量策略测试

不需要构造一个承诺“预测最终网络速度”的重型模拟器。应在设备策略内增加轻量测试：

```text
输入：设备 + 应用/域名 + 时间
输出：命中设备策略、应用规则、有效解析组、静态域名规则和允许/阻断结论
```

需要明确：最终 DNS 上游、缓存结果和最快 IP 取决于实时健康与测速，不能由静态预览保证。

#### 6.3 网络覆盖与绕过检测

家庭策略的真实问题常常是设备没有使用 SmartDNS。应新增“网络保护覆盖”能力：

- 已识别设备、已覆盖设备、未覆盖设备；
- IPv4/IPv6 DNS 泄漏；
- 外部 DNS、DoT、DoH/DoQ、VPN 绕过的可见迹象；
- 路由器、DHCP、iptables/nftables/OpenWrt 修复指引；
- 每台设备显示完整覆盖、部分覆盖、已绕过或未知。

### P1：提升配置安全和长期运行体验

- 用户可见的配置版本、差异、备份、恢复和一键回滚；
- 保存前预检：空解析组、继承循环、端口冲突、无上游、无效代理引用、IPv6 配置冲突；
- 策略变更影响分析：会影响哪些设备、应用和规则；
- 上游和代理持续健康评分、趋势、故障切换记录与告警；
- 访问诊断报告：结论、置信度、证据、建议和修复历史。

### P2：生态和高级用户能力

- Prometheus/OpenMetrics 与 Grafana Dashboard；
- Home Assistant/HACS 集成；
- OpenWrt/LuCI、Docker、NAS、配置即代码和 Git 工作流；
- 手机端 PWA/Capacitor 管理能力；
- 多实例主备、配置同步和灾备。

## 7. 手机端管理

### 7.1 推荐技术路线

现有 Next/React WebUI 应优先做响应式和 PWA，而不是立即重写原生 UI：

```text
响应式 WebUI
  -> PWA 安装到主屏幕
    -> 需要原生能力时用 Capacitor 包装
```

可复用现有页面、组件、国际化、REST/WebSocket 和策略模型。需要针对手机重做的主要是宽表格、左侧导航、复杂弹窗、登录凭据、局域网发现和网络切换。

仅 WebView 套壳价值有限；只有需要二维码配对、推送、mDNS/局域网发现、系统 DNS 配置、VPN 或系统安全存储时，才值得加入 Capacitor 原生壳。

### 7.2 安全边界

- 默认不把管理端口暴露到公网；
- 手机通过局域网、VPN 或受信任远程通道访问；
- 首次连接使用二维码和一次性配对令牌；
- 配对令牌可撤销、可过期；
- iPhone 私有 Wi-Fi 地址可能改变 MAC，应在 UI 中提示重新关联。

## 8. Home Assistant、语音控制与 Prometheus

### 8.1 Home Assistant 的价值

Home Assistant 不应替代 SmartDNS 执行策略。正确分工是：

```text
SmartDNS：本地、稳定、实时的 DNS 与设备策略执行
Home Assistant：按家庭场景、人在不在家、日历、传感器和自动化做编排
```

基础定时限制必须在 SmartDNS 本地运行，避免 HA 故障导致儿童策略失效。HA 适合处理动态例外：访客模式、观影模式、旅行模式、睡眠场景、门锁/在家状态联动和临时授权。

可暴露的 HA 实体：

```text
sensor.smartdns_query_count
sensor.smartdns_block_rate
sensor.smartdns_cache_hit_rate
binary_sensor.smartdns_upstream_healthy
binary_sensor.smartdns_network_coverage_healthy
select.smartdns_<device>_profile
sensor.smartdns_<device>_top_app
sensor.smartdns_<device>_failed_queries
```

应用不应全部变为 HA 开关，以免实体爆炸。应提供语义化服务：

```text
smartdns.set_client_profile
smartdns.set_temporary_access
smartdns.end_temporary_access
smartdns.start_access_diagnosis
smartdns.refresh_subscription
```

Home Assistant 的实体与自定义服务模型适合此类集成，参考：[Home Assistant Devices and Services](https://developers.home-assistant.io/docs/architecture/devices-and-services/)。

### 8.2 语音控制

HA 语音本身不是单独的大项目。只要上述 HA 服务完成，HA Assist、Siri Shortcuts 或 Android App Actions 就能表达：

```text
“给小明的 iPad 开放 YouTube 半小时。”
“儿童上网保护现在是否开启？”
“开始诊断我的 iPhone 为什么打不开 App Store。”
```

SmartDNS 不应自己承担语音识别或通用自然语言理解。语音层只调用受限、可确认、可审计的意图接口。

### 8.3 Prometheus/OpenMetrics

Prometheus 比 HA 语音更普适，建议优先落地。提供只读 `/metrics`，至少包括：

```text
smartdns_dns_queries_total
smartdns_dns_query_duration_seconds
smartdns_dns_cache_hits_total
smartdns_dns_blocked_queries_total
smartdns_upstream_healthy
smartdns_upstream_query_duration_seconds
smartdns_proxy_connections
smartdns_proxy_bytes_total
smartdns_policy_blocked_queries_total
smartdns_config_apply_failures_total
```

不要把域名、客户端 IP、MAC 用作 Prometheus Label；这会带来高基数、隐私泄漏和 Prometheus 性能问题。Label 只使用协议、响应码、解析组、上游名称等受控值。

### 8.4 HA 集成认证设计

现有 WebUI JWT 适合浏览器会话，不应直接交给 Home Assistant：它绑定来源 IP，且现有受保护路由权限粒度较粗。

应增加集成访问令牌：

```text
令牌：sdn_<id>.<随机密钥>
存储：仅存储密钥哈希，明文只展示一次
限制：可设置有效期、撤销和 Home Assistant 来源 IP/CIDR
```

推荐 Scope：

```text
stats.read
clients.read
policies.read
policies.bind
overrides.write
```

禁止集成令牌访问终端、证书、密码、原始 DNS 配置 CRUD、删除配置和代理/监听器配置。

为 HA 提供语义化版本化接口，而不是暴露通用后台接口：

```text
GET  /api/integrations/v1/overview
GET  /api/integrations/v1/clients
GET  /api/integrations/v1/clients/{id}
PUT  /api/integrations/v1/clients/{id}/profile
POST /api/integrations/v1/clients/{id}/temporary-access
DELETE /api/integrations/v1/temporary-access/{id}
```

每次写操作应记录 Token、调用者、设备、策略、时间、请求 ID，并支持幂等键。HTTPS、证书校验、临时放行最大时长和 Token 独立撤销是发布前提。

### 8.5 工作量估计

| 项目 | 估计 |
| --- | ---: |
| Home Assistant 集成业务代码（状态、客户端、策略切换、临时放行） | 约 760–1,100 行 Python |
| SmartDNS 集成令牌、Scope、语义化 API | 约 400–800 行 Rust，外加测试 |
| 可发布 HA 集成（认证、测试、HACS、文档） | 14–22 人天 |
| 基础 Prometheus `/metrics` | 3–5 人天 |
| 完整按组/上游指标和测试 | 7–12 人天 |

Home Assistant 在全球已有超过 200 万活跃安装，但主要集中在智能家居、NAS、OpenWrt、Homelab 和隐私本地化用户。该群体与 SmartDNS 用户高度重叠；中国没有可靠公开装机量，适合视为国内高级用户生态入口，而非面向普通家庭的主获客渠道。[Home Assistant 2025 数据](https://www.home-assistant.io/blog/2025/05/07/release-20255/)

## 9. 不应过度宣传或过早承诺的能力

- 不把单个代理出口称为“代理池/智能负载均衡”，除非真正实现了多出口选择、健康检查和故障切换；
- 不承诺“自动识别所有视频网站代理域名”；应用目录和诊断只能提供有置信度的建议；
- 不承诺“DNS 正常即网页一定可用”；DNS 只能证明解析，不能证明应用层服务；
- 不把未合并或未发布的 DHCP 功能列为正式能力；
- 不宣称完整兼容全部 AdGuard/Adblock 规则语法，除非有明确的兼容范围和测试；
- 不让数据转发成为所有用户必须理解的配置。

## 10. 对外宣传建议

### 10.1 主张

```text
更快：同时使用多个上游，选择更适合当前网络的解析结果。
更可控：按设备、应用、时间和网络策略管理访问。
更可解释：手机打不开或变慢时，给出 DNS、规则、双栈和转发证据。
```

### 10.2 一句话定位

> SmartDNS：让家庭网络的 DNS 更快，让每台设备的访问策略更可控，让网络问题有证据可查。

### 10.3 不同用户的入口

| 用户 | 首要入口 | 核心价值 |
| --- | --- | --- |
| 普通家庭 | Access Control、Clients、Access Diagnostics | 管孩子设备、应用和访问问题 |
| 路由器/旁路由用户 | Network Policy Center、Traffic Topology、Data Forwarding | DNS 与真实网络路径统一管理 |
| 高级用户/运维人员 | Prometheus、日志、上游健康、配置版本 | 长期运行、告警和自动化 |
| 智能家居用户 | Home Assistant 集成 | 将网络策略纳入家庭场景与语音控制 |

## 11. 成功标准

产品演进应以用户结果衡量，而不以页面或配置项数量衡量：

- 用户能否在 3 分钟内为一个设备创建应用限制；
- 用户能否在一次复现后理解“为什么打不开/慢”；
- 用户能否确认策略是否真的覆盖该设备；
- 一次错误配置能否在保存前发现，或在一分钟内回滚；
- 高级用户能否接入 HA、Prometheus/Grafana，而无需复用管理员会话；
- 应用目录的误归类和共享 CDN 风险是否可见、可撤销、可反馈。

当这些结果稳定达成时，SmartDNS 将不只是一个高性能 DNS 服务，而是一个可被普通家庭使用、也能被高级用户长期信任的网络控制中心。
